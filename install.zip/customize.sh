UM=1
SKIPUNZIP=1

MODEL=$(getprop ro.product.model)
ZUI_VERSION=$(getprop ro.build.display.id | grep -o 'ZUI_[0-9.]*_ST' | cut -d'_' -f2)

# Define target versions and conditions
TARGET_VERSION_TB371FC="150440"
CONDITION_TB371FC='[ "$ZUI_VERSION_NUM" -ge "$TARGET_VERSION_TB371FC" ]'  # Xiaoxin Pad 2024

TARGET_VERSION_TB331FC="151105"
CONDITION_TB331FC='[ "$ZUI_VERSION_NUM" -ge "$TARGET_VERSION_TB331FC" ] && [ "$ZUI_VERSION_NUM" -lt "160000" ]'  # XiaoXin Pad Pro 12.7

TARGET_VERSION_TB9707F="150774"
CONDITION_TB9707F='[ "$ZUI_VERSION_NUM" -ge "$TARGET_VERSION_TB9707F" ]'  # Legion Y700

# Default value for unknown models
DEFAULT_TARGET_VERSION="160000"
DEFAULT_CONDITION='[ "$ZUI_VERSION_NUM" -ge "$DEFAULT_TARGET_VERSION" ]'

# Determine the target version and condition based on the model
case "$MODEL" in
    "TB371FC")
        TARGET_VERSION="$TARGET_VERSION_TB371FC"
        CONDITION="$CONDITION_TB371FC"
        ;;
    "TB331FC")
        TARGET_VERSION="$TARGET_VERSION_TB331FC"
        CONDITION="$CONDITION_TB331FC"
        ;;
    "TB-9707F")
        TARGET_VERSION="$TARGET_VERSION_TB9707F"
        CONDITION="$CONDITION_TB9707F"
        ;;
    *)
        TARGET_VERSION="$DEFAULT_TARGET_VERSION"
        CONDITION="$DEFAULT_CONDITION"
        ;;
esac

RM_RF() {
    rm -rf $MODPATH/files 2>/dev/null
}

MODPRINT() {
    ui_print "┏━━━━┳┓╋┏┳━━┳━━━━┳━━━┳━━━┳━┓╋┏┳━━━┳┓╋╋┏━━━┳━━━━┳━━━┳━━━┓"
    ui_print "┗━━┓━┃┃╋┃┣┫┣┫┏┓┏┓┃┏━┓┃┏━┓┃┃┗┓┃┃┏━┓┃┃╋╋┃┏━┓┃┏┓┏┓┃┏━┓┃┏━┓┃"
    ui_print "╋╋┏┛┏┫┃╋┃┃┃┃┗┛┃┃┗┫┗━┛┃┃╋┃┃┏┓┗┛┃┗━━┫┃╋╋┃┃╋┃┣┛┃┃┗┫┃╋┃┃┗━┛┃"
    ui_print "╋┏┛┏┛┃┃╋┃┃┃┃╋╋┃┃╋┃┏┓┏┫┗━┛┃┃┗┓┃┣━━┓┃┃╋┏┫┗━┛┃╋┃┃╋┃┃╋┃┃┏┓┏┛"
    ui_print "┏┛━┗━┫┗━┛┣┫┣┓╋┃┃╋┃┃┃┗┫┏━┓┃┃╋┃┃┃┗━┛┃┗━┛┃┏━┓┃╋┃┃╋┃┗━┛┃┃┃┗┓"
    ui_print "┗━━━━┻━━━┻━━┛╋┗┛╋┗┛┗━┻┛╋┗┻┛╋┗━┻━━━┻━━━┻┛╋┗┛╋┗┛╋┗━━━┻┛┗━┛"
    ui_print "                    𝙱𝚢 𝙻𝚎𝚢𝚛𝚂𝚑𝚛𝚘𝚞𝚍; 𝚃𝙶: @𝚕e𝚢𝚛𝚢𝚣               "
    ui_print "- Model: $MODEL"
    ui_print "- Software version: $ZUI_VERSION"
    ui_print ""
    MODEXTRACT
    ui_print ""
    ui_print "- NOTE -"
    ui_print "• If you are still having problems with your system locale after installing the module, contact @layryz (TG) for help."
    ui_print "• When installing the module, the system locale will be forcibly changed to \"ru-RU\"."
    ui_print ""
    MODADDON
    ui_print ""
    MODPERM
}

MODEXTRACT() {
    ui_print "- Extracting module files"
    unzip -o "$ZIPFILE" devicelingo.sh -d $MODPATH >&2
    unzip -o "$ZIPFILE" module.prop -d $MODPATH >&2
    unzip -o "$ZIPFILE" system.prop -d $MODPATH >&2
    unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
    unzip -o "$ZIPFILE" 'files/*' -d $MODPATH >&2
}

MODADDON() {
    # Check ZUI version and install CtsPreconditions.apk if needed
    ZUI_VERSION_NUM=$(echo "$ZUI_VERSION" | sed 's/\.//g')

    # Call of functions
    codename_check
    checkZUIVersionForAPK

    if [ -n "$ZUI_VERSION_NUM" ]; then
        eval CONDITION # Evaluate the condition variable
        if eval "$CONDITION"; then
            if [ "$(settings get system system_locales)" != "ru-RUzhzh" ]; then
                su -c settings put system system_locales "ru-RUzhzh"
                su -c settings put global settings_app_locale_opt_in_enabled false
                ui_print "╠ ▪️ The value for the fix has been successfully set!"
            else
                ui_print "╠ ▪️ The value to fix is already present in the system."
            fi
        else
            if [ "$(settings get system system_locales)" != "ru-RU" ]; then
                su -c settings put system system_locales "ru-RU"
                su -c settings put global settings_app_locale_opt_in_enabled false
                ui_print "╠ ▪️ Third-party system locale detected, setting value to \"ru-RU\"."
            else
                ui_print "╠ ▪️ The value to fix is already present in the system."
            fi
            ui_print "╠ ▪️ ZUI $ZUI_VERSION requires no additional manipulation. Skip installation."
        fi
        source "$MODPATH/devicelingo.sh"
    else
        ui_print "╠ ▪️ Unable to determine ZUI version."
    fi

    sleep 3
    ui_print ""
    ui_print "- Successful installation!"
}

checkZUIVersionForAPK() {  # Copies tweaked APKs when ZUI >= 16
    if [ "$ZUI_VERSION_NUM" -ge "160000" ]; then
        cp -rf $MODPATH/files/specificapk/ZuiSecurity.apk $MODPATH/system/product/overlay/
        ui_print "╠ ▪️ ZUI 16 detected, tweaked overlays are used."
    fi
}

codename_check() {  # Checking individual device requirements
    if [ "$MODEL" = "TB128FU" ]; then  # XiaoXin Pad 2022
        cp -rf $MODPATH/files/specificapk/ZuiCamera.apk $MODPATH/system/product/overlay/
        ui_print "╠ ▪️ Backup camera overlay used for TB128FU."
    fi 
    if [ "$MODEL" = "TB371FC" ]; then  # XiaoXin Pad Pro 12.7
        cp -rf $MODPATH/files/additapk/* $MODPATH/system/product/overlay/
        cp -rf $MODPATH/files/vendor/* $MODPATH/system/vendor/
        cp -rf $MODPATH/files/system.prop $MODPATH
        ui_print "╠ ▪️ Additional APKs for correct operation used for TB371FC."
    fi
    if [ "$MODEL" = "J716F" ]; then  # XiaoXin Pad Pro 2021
        rm -f $MODPATH/system/product/overlay/ZuiCamera.apk
        ui_print "╠ ▪️ Standard camera overlay used for J716F."
    fi
    if [ "$MODEL" = "TB331FC" ]; then  # Xiaoxin Pad 2024
        cp -rf $MODPATH/files/additapk/* $MODPATH/system/product/overlay/
        cp -rf $MODPATH/files/vendor/* $MODPATH/system/vendor/
        cp -rf $MODPATH/files/system.prop $MODPATH
        ui_print "╠ ▪️ Additional APKs for correct operation used for TB331FC."
    fi
}

MODPERM() {
    set_perm_recursive $MODPATH 0 0 0755 0644
}

MODSET() {
    sed -i "/description=/c description=${TEXT1}" $MODPATH/module.prop
}

if [ ! "$SKIPUNZIP" = "0" ]; then
    set -x
    MODPRINT
else
    set +x
    abort
fi

RM_RF